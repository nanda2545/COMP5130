
# FadeNote: Secure Self-Destructing Notes Application

## Description
This project is a basic implementation of a secure self-destructing notes application using Node.js, Express, and MongoDB. Users can create encrypted notes that will self-destruct after being read or after a specified period.

## Features
- Create notes with encrypted content.
- Set notes to self-destruct after being read or after a specified time.
- Share notes via unique URL.

## Installation

1. Clone the repository
2. Run `npm install` to install dependencies
3. Start the server using `npm start`
4. MongoDB should be running locally at `mongodb://localhost/tempnote`

## Endpoints

- `POST /createNote`: Create a new encrypted note.
- `GET /readNote/:id`: Read and self-destruct the note.
