
const express = require('express');
const mongoose = require('mongoose');
const crypto = require('crypto');
const app = express();
const port = 3000;

// MongoDB setup
mongoose.connect('mongodb://localhost/tempnote', { useNewUrlParser: true, useUnifiedTopology: true });
const noteSchema = new mongoose.Schema({
    content: String,
    password: String,
    expiresAt: Date,
    isRead: { type: Boolean, default: false }
});
const Note = mongoose.model('Note', noteSchema);

// Middleware
app.use(express.json());

// Helper function for encryption
function encrypt(text) {
    const cipher = crypto.createCipher('aes-256-cbc', 'd6F3Efeq');
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}

// Helper function for decryption
function decrypt(text) {
    const decipher = crypto.createDecipher('aes-256-cbc', 'd6F3Efeq');
    let decrypted = decipher.update(text, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

// Create a new note
app.post('/createNote', async (req, res) => {
    const { content, password, expiresIn } = req.body;
    const encryptedContent = encrypt(content);
    const expiresAt = new Date(Date.now() + expiresIn * 60000); // expiresIn is in minutes
    const newNote = new Note({ content: encryptedContent, password, expiresAt });
    await newNote.save();
    res.status(201).send({ message: 'Note created successfully', noteId: newNote._id });
});

// Read and delete a note
app.get('/readNote/:id', async (req, res) => {
    const note = await Note.findById(req.params.id);
    if (!note || note.isRead || new Date() > note.expiresAt) {
        return res.status(404).send({ message: 'Note not found or already read' });
    }
    note.isRead = true;
    await note.save();
    const decryptedContent = decrypt(note.content);
    res.send({ content: decryptedContent });
});

// Start server
app.listen(port, () => {
    console.log(`FadeNote app listening at http://localhost:${port}`);
});
